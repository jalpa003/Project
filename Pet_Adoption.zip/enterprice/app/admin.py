from django.contrib import admin
from .models import user
from .models import pet
from .models import pet_type
from .models import breed
from .models import que
from .models import answer
from .models import feedback
from .models import contact

# Register your models here.
admin.site.register(user)
admin.site.register(pet)
admin.site.register(pet_type)
admin.site.register(breed)
admin.site.register(que)
admin.site.register(answer)
admin.site.register(feedback)
admin.site.register(contact)
