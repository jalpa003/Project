from django.shortcuts import render
from django.http import HttpResponse
from .models import user
from .models import pet
from .models import pet_type
from .models import breed
from .models import que
from .models import feedback
from .models import answer
from django.contrib import auth
#from django.contrib.auth.views import logout

from .models import contact
# Create your views here.
listusers=[]

def sign(request):    
    return render(request,'sign.html')

def signupcheck(request):
	name=request.GET.get('name')
	psw=request.GET.get('psw') 
	email = request.GET.get("email")
	fname = request.GET.get("fname")
	mname = request.GET.get("mname")
	lname = request.GET.get("lname")
	mobno = request.GET.get("num")  
	newuser={"name":name,"psw":psw,"email":email,"fname":fname,"mname":mname,"lname":lname,"mobno":mobno}
	listusers.append(newuser)
	user.objects.create(username=name,password=psw,email=email,fname=fname,mname=mname,lname=lname,mobno=mobno)
	listuser=user.objects.all()
	return render(request,'login.html')

def login(request):    
    return render(request,'login.html')

def logincheck(request):  
	name=request.GET.get('name')
	psw=request.GET.get('psw') 
	print(name)
	print(psw)
	listuser=user.objects.all()
	dict1={"user":listuser}
	print(dict1)
	for i in listuser:
		print(i.username)
		print(i.password)
		Flag=False
		if(i.username==name and i.password==psw):
			# Flag=True
			# if(flag==True):
			# 	listuser=user.objects.all()
			request.session['name']=name
			return render(request,'home.html')

		 #else:	
		# 	return render(request,'login.html')
def home(request):
	
	return render(request,'home.html')
def display(request):
	l1 = pet.objects.all()
	dictd = {'display':l1}
	return render (request ,'petdetails.html',dictd)
def search(request):
	return render(request,'search.html')
def searchpage(request):
	sp = request.GET.get("d","c")
	l1=pet.objects.filter(Species=sp)
	dictd = {'display':l1}
	return render (request ,'petdetails.html',dictd)
def contactus(request):
	return render(request,'contactus.html')
def contactadd(request):
	fname = request.GET.get('fname')
	lname = request.GET.get('lname')
	email = request.GET.get('email')
	message = request.GET.get('message')		
	print(fname)
	print(lname)
	listcc=[]
	dictcc = {"fname":fname,"lname":lname,"email":email,"message":message}
	print(dictcc)
	listcc.append(dictcc)
	contact.objects.create(fname=fname,lname=lname,email=email,message=message)
	contact.objects.all()
	return render(request,'home.html')
def feedadd(request):
	email=request.GET.get('email')
	message=request.GET.get('txt')
	print(email)
	print(message)
	feedback.objects.create(email=email,message=message)
	feedback.objects.all()
	return render(request,'home.html')
def feed(request):
	return render(request,'feedback.html')
	
def ques(request):
	l2 = que.objects.all()
	dictq = {'ques' : l2}
	return render (request,'ques.html',dictq)
def ans(request):
	answer = request.GET.get('a.id')
	print(ans)
	answer.objects.create(answer=answer)
	answer.objects.all()
	return render(request,'home.html')
def blog(request):    
    return render(request,'blogs.html')
def logout(request):
    auth.logout(request)
    return render(request,'logout.html')

    

